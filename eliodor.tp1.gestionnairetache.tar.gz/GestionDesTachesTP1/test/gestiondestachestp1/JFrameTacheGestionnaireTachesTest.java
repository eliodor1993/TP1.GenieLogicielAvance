/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gestiondestachestp1;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author nowyouseeme
 */
public class JFrameTacheGestionnaireTachesTest {
    
    public JFrameTacheGestionnaireTachesTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }

    /**
     * Test of AjoutTache method, of class JFrameTacheGestionnaireTaches.
     */
    @Test
    public void ajouter(){
        int id = 76;
        String nom ="Programmeur";
        String description="Coder la page d'acceuil";
        String status = "Nouveau";
    }
    
    public void testAjoutTache() {
        System.out.println("AjoutTache");
        JFrameTacheGestionnaireTaches instance = new JFrameTacheGestionnaireTaches();
        instance.AjoutTache();
        int id = 76;
        String nom ="Programmeur";
        String description="Coder la page d'acceuil";
        String status = "Nouveau";
        instance.connecterDansBase.AjouterTache(id, nom, description, status);
    }


    /**
     * Test of ModificationTache method, of class JFrameTacheGestionnaireTaches.
     */
    @Test
    public void modifier(){
        int id = 76;
        String nom ="lead manager";
        String description="Gerer le groupe pendant un sprint";
        String status = "Nouveau";
    }
    public void testModificationTache() {
        System.out.println("ModificationTache");
        JFrameTacheGestionnaireTaches instance = new JFrameTacheGestionnaireTaches();
        instance.ModificationTache();
        int id = 76;
        String nom ="lead manager";
        String description="Gerer le groupe pendant un sprint";
        String status = "Nouveau";
        instance.connecterDansBase.ModifierTache(id, nom, description, status);
    }

    /**
     * Test of SupprimerUneTache method, of class JFrameTacheGestionnaireTaches.
     */
    @Test
     public void suppression(){
        int id = 76;
     }
     
    public void testSupprimerUneTache() {
        System.out.println("SupprimerUneTache");
        int idtache = 0;
        JFrameTacheGestionnaireTaches instance = new JFrameTacheGestionnaireTaches();
        instance.SupprimerUneTache(idtache);
        int id = 76;
        instance.connecterDansBase.SupprimerTache(id);
        
    }

    /**
     * Test of main method, of class JFrameTacheGestionnaireTaches.
     */
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        JFrameTacheGestionnaireTaches.main(args);

    }
    
}
