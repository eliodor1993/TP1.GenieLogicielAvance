//*********************************************************//
//              ELIODOR Ednalson Guy Mirlin                //
//                                                         //
//              TP1 - Genie Logiciel Avance                //
//                                                         //
//             Un petit gestionnaire de tache              //
//                                                         //
//                                                         //
//*********************************************************//

package gestiondestachestp1;

import java.sql.*;
import javax.swing.JOptionPane;

public class Connectionbase_gestiontachetp1 {
    Connection connecterbase;
    Statement statementbase;
    ResultSet resultSET;
    
//classe permettant de gerer la connection entre l´application et la base de donnees :gestiontachetp1
   public Connectionbase_gestiontachetp1(){
        try{
            Class.forName("com.mysql.jdbc.Driver");
        }
            catch(ClassNotFoundException e){
            System.err.println(e);
            }
        
        try{
            //mise en place de la connection. Dans notre cas le user s'appelle root et le mot de passe c'est: ee
            connecterbase=(Connection) DriverManager.getConnection("jdbc:mysql://localhost/gestiontachetp1","root","ee");
        }
            catch(SQLException e){
                System.err.println(e);
            }
    }

//Methode agissant avec la base de donnees permettant de recuperer la procedure (ajoutermembre) dans la base
//Cette methode servira de pont entre la base et la methode permettant d'ajouter ou creer un membre dans la
//classe JFrameMembreGestionnaireMembre

  //Ainsi de suite pour les autres methodes ici present
public void AjouterMembre(int idmembre, String nommembre){
        try{
          if(statementbase != null)
            statementbase.close();
             statementbase = connecterbase.createStatement();
            String requeteDansBase = "call ajoutermembre('"+idmembre+"','"+nommembre+"')";
            statementbase.executeUpdate(requeteDansBase);
        }
        catch(SQLException e){ System.out.println("Erreur insertion donnee dans la table membre");
        } 
   }
   
   public void AjouterTache(int idtache, String nomtache, String descriptiontache, String statustache){
	    try{
	      if(statementbase != null)
                statementbase.close();
                 statementbase = connecterbase.createStatement();
	        String requeteDansBase = "call ajoutertache ('"+idtache+"','"+nomtache+"','"+descriptiontache+"','"+statustache+"')";
	        statementbase.executeUpdate(requeteDansBase);
                JOptionPane.showMessageDialog(null,"ajout reussi.");
	    }
	    catch(SQLException e){ JOptionPane.showMessageDialog(null, "Erreur insertion donnee dans la table tache");
	    } 
	   }
   
   public void Ajouterassignation(int idtache, int idmembre){
	    try{
	      if(statementbase != null)
                statementbase.close();
                 statementbase = connecterbase.createStatement();
	        String requeteDansBase = "call ajouterassignation('"+idtache+"','"+idmembre+"')";
	        statementbase.executeUpdate(requeteDansBase);
                JOptionPane.showMessageDialog(null,"Assignation reussie.");
	    }
	    catch(SQLException e){
                JOptionPane.showMessageDialog(null,"Erreur insertion donnee dans la table assigneTache");
	    }
	   }
   
   public ResultSet AffichageDesMembres(){
	   ResultSet rSet = null;
    try{
      if(statementbase != null)
       statementbase.close();
        statementbase = connecterbase.createStatement();
        String requete = "call afficherMembre ()";
        rSet = statementbase.executeQuery(requete);              
    }
    catch(SQLException e){ 
        JOptionPane.showMessageDialog(null,"Il y a une erreur lors de l'affichage des membres");
    }
   return rSet;
   }
    
    public ResultSet AffichageDesTaches(){
	   ResultSet rSet = null;
    try{
      if(statementbase != null)
            statementbase.close();
        statementbase = connecterbase.createStatement();
        String requete = "call afficherTache ()";
        rSet = statementbase.executeQuery(requete);              
    }
    catch(SQLException e){ 
        JOptionPane.showMessageDialog(null,"Il y a une erreur lors de l'affichage des taches");
    }
   return rSet;
   }
    
   public ResultSet AffichageDesAssignations(){
	   ResultSet rSet = null;
    try{
      if(statementbase != null)
            statementbase.close();
        statementbase = connecterbase.createStatement();
        String requete = "call afficherAssignation ()";
        rSet = statementbase.executeQuery(requete);              
    }
    catch(SQLException e){ 
        JOptionPane.showMessageDialog(null,"Il y a une erreur lors de l'affichage des assignations");
    }
   return rSet;
   }
    


   public ResultSet SupprimerMembre(int idmembre){
        ResultSet resultatSuppression = null;
        try{
            if(statementbase != null)
            statementbase.close();
                statementbase = connecterbase.createStatement();
            String requeteDansBase = "call supprimermembre('"+idmembre+"')";
            resultatSuppression = statementbase.executeQuery(requeteDansBase);              
        }
        catch(SQLException e){
            JOptionPane.showMessageDialog(null,"Erreur suppression donnee dans la table Membre");
        }
        return resultatSuppression;
   } 
   
   public ResultSet SupprimerTache(int idtache){
	   ResultSet resultatSuppression = null;
    try{
      if(statementbase != null)
       statementbase.close();
        statementbase = connecterbase.createStatement();
        String requeteDansBase = "call supprimertache ('"+idtache+"')";
        resultatSuppression = statementbase.executeQuery(requeteDansBase);  
        JOptionPane.showMessageDialog(null,"Suppression reussie.");
    }
    catch(SQLException e){ 
        JOptionPane.showMessageDialog(null,"Erreur suppression donnee dans la table Tache");
    }
        return resultatSuppression;
   } 

   
   public void ModifierMembre(int idmembre, String nommembre){
    try{
      if(statementbase != null)
           statementbase.close();
        statementbase = connecterbase.createStatement();
        String requeteDansBase = "call modifiermembre('"+idmembre+"','"+nommembre+"')";
        statementbase.executeUpdate(requeteDansBase);
        JOptionPane.showMessageDialog(null,"modification reussie.");
    }
    catch(SQLException e){ 
        JOptionPane.showMessageDialog(null,"Erreur modification donnee dans la table Membre");
    }
    }
     
   
   public void ModifierTache(int idtache, String nomtache, String descriptiontache, String statustache){
    try{
      if(statementbase != null)
           statementbase.close();
        statementbase = connecterbase.createStatement();
        String requeteDansBase = "call modifiertache('"+idtache+"','"+nomtache+"','"+descriptiontache+"','"+statustache+"')";
        statementbase.executeUpdate(requeteDansBase);
        JOptionPane.showMessageDialog(null,"modification reussie.");
    }
    catch(SQLException e){ 
    JOptionPane.showMessageDialog(null,"Erreur modification donnee dans la table Tache");
    }
   }  
   
   public ResultSet RechercherParIdMembre(int idmembre){
        resultSET = null;
        try{
           if(statementbase != null)
            statementbase.close();
             statementbase = connecterbase.createStatement();
             String requete = "call rechercheSuivantValeurIdMembre('"+idmembre+"')";              
             resultSET = statementbase.executeQuery(requete);    
         }
         catch(SQLException e){ 
            JOptionPane.showMessageDialog(null,"Erreur de recherche donnee dans la table assigneMembre \n verifier les donnees dans la base");
         }
        return resultSET;
    }
   
  
    
     public ResultSet RechercherParStatusTache(String statustache){
        resultSET = null;
        try{
           if(statementbase != null)
            statementbase.close();
             statementbase = connecterbase.createStatement();
             String requeteDansBase = "call rechercheSuivantValeurStatusTache('"+statustache+"')";              
             resultSET = statementbase.executeQuery(requeteDansBase);    
         }
         catch(SQLException e){ 
JOptionPane.showMessageDialog(null,"Erreur de recherche donnee dans la table assigneMembre \n verifier les donnees dans la base");
         }
        return resultSET;
    }
   
}