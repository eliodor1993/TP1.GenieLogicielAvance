-- phpMyAdmin SQL Dump
-- version 4.6.6deb4
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Aug 19, 2017 at 03:53 PM
-- Server version: 5.7.19-0ubuntu0.17.04.1
-- PHP Version: 7.0.22-0ubuntu0.17.04.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `gestiontachetp1`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `afficherAssignation` ()  NO SQL
SELECT *
FROM gestiontachetp1.tache
INNER JOIN gestiontachetp1.assignetache
ON assignetache.idtache = tache.idtache
RIGHT JOIN gestiontachetp1.membre
ON (membre.idmembre = assignetache.idmembre AND tache.idtache = assignetache.idtache)
WHERE (membre.idmembre AND tache.idtache)$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `afficherMembre` ()  NO SQL
SELECT * FROM gestiontachetp1.membre$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `afficherTache` ()  NO SQL
SELECT * FROM gestiontachetp1.tache$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `ajouterassignation` (IN `idtache` INT(11), IN `idmembre` INT(11))  NO SQL
INSERT INTO gestiontachetp1.assignetache VALUES(idtache, idmembre)$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `ajoutermembre` (IN `idmembre` INT(10), IN `nommembre` VARCHAR(100))  NO SQL
INSERT INTO gestiontachetp1.membre VALUES(idmembre, nommembre)$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `ajoutertache` (IN `idtache` INT(10), IN `nomtache` VARCHAR(150), IN `descriptiontache` VARCHAR(255), IN `statustache` VARCHAR(15))  NO SQL
INSERT INTO gestiontachetp1.tache VALUES(idtache,nomtache,descriptiontache,statustache)$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `modifiermembre` (IN `idmembre` INT(10), IN `nommembre` VARCHAR(100))  NO SQL
UPDATE gestiontachetp1.membre SET membre.idmembre= IF(idmembre = '', membre.idmembre, idmembre) , membre.nommembre= IF(nommembre = '', membre.nommembre, nommembre) WHERE membre.idmembre=idmembre$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `modifiertache` (IN `idtache` INT(10), IN `nomtache` VARCHAR(150), IN `descriptiontache` VARCHAR(255), IN `statustache` VARCHAR(15))  NO SQL
UPDATE gestiontachetp1.tache SET tache.idtache= IF(idtache = '', tache.idtache, idtache) , tache.nomtache= IF(nomtache = '', tache.nomtache, nomtache) , tache.descriptiontache= IF(descriptiontache = '', tache.descriptiontache, descriptiontache) , tache.statustache= IF(statustache = '', tache.statustache, statustache) WHERE tache.idtache=idtache$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `rechercheSuivantValeurIdMembre` (IN `idmembre` INT(10))  NO SQL
SELECT gestiontachetp1.tache.idtache, gestiontachetp1.tache.nomtache, gestiontachetp1.tache.descriptiontache, gestiontachetp1.tache.statustache, gestiontachetp1.membre.idmembre, gestiontachetp1.membre.nommembre
FROM tache
INNER JOIN assignetache
ON assignetache.idtache = tache.idtache
RIGHT JOIN membre
ON membre.idmembre = assignetache.idmembre
WHERE membre.idmembre = idmembre$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `rechercheSuivantValeurStatusTache` (IN `statustache` VARCHAR(15))  NO SQL
SELECT gestiontachetp1.tache.idtache, gestiontachetp1.tache.nomtache, gestiontachetp1.tache.descriptiontache, gestiontachetp1.tache.statustache, gestiontachetp1.membre.idmembre, gestiontachetp1.membre.nommembre
FROM tache
INNER JOIN assignetache
ON assignetache.idtache = tache.idtache
RIGHT JOIN membre
ON membre.idmembre = assignetache.idmembre
WHERE tache.statustache = statustache$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `supprimermembre` (IN `idmembre` INT(10))  NO SQL
DELETE FROM gestiontachetp1.membre WHERE membre.idmembre = idmembre$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `supprimertache` (IN `idtache` INT(10))  NO SQL
DELETE FROM gestiontachetp1.tache WHERE tache.idtache = idtache$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `assignetache`
--

CREATE TABLE `assignetache` (
  `idtache` int(10) NOT NULL,
  `idmembre` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `assignetache`
--

INSERT INTO `assignetache` (`idtache`, `idmembre`) VALUES
(1, 1),
(2, 1),
(11, 9),
(33, 33),
(44, 44);

-- --------------------------------------------------------

--
-- Table structure for table `membre`
--

CREATE TABLE `membre` (
  `idmembre` int(10) NOT NULL,
  `nommembre` varchar(100) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `membre`
--

INSERT INTO `membre` (`idmembre`, `nommembre`) VALUES
(1, 'Eliodor Ednalson'),
(2, 'Pierre Ridly'),
(3, 'Jean Peterson'),
(4, 'Etienne Pierre R'),
(5, 'Luiz Gym'),
(6, 'Dorleon Ginel'),
(7, 'Gervais Sikadie'),
(8, 'Andre Perrault'),
(9, 'Jean Baptiste '),
(10, 'Frantz Jean'),
(33, 'sahsgah'),
(44, 'Delacruz Stephano');

-- --------------------------------------------------------

--
-- Table structure for table `tache`
--

CREATE TABLE `tache` (
  `idtache` int(10) NOT NULL,
  `nomtache` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `descriptiontache` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `statustache` varchar(15) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tache`
--

INSERT INTO `tache` (`idtache`, `nomtache`, `descriptiontache`, `statustache`) VALUES
(1, 'scrum master', 'asass', 'En Progres'),
(2, 'relPublic', 'Gestion de la relation Pub du groupe', 'Nouveau'),
(3, 'sdsds', 'sds ssd sfsfds ', 'Nouveau'),
(10, 'modeliser l\'apk', 'Gestion de la modelisation en UML', 'Nouveau'),
(11, 'programmeur', 'coder le systeme', 'Nouveau'),
(33, 'dhjdhajs', 'asasga', 'Nouveau'),
(44, 'sdsds', 'ewew', 'Nouveau'),
(56, 'ELIODORjasas', 'dshdajshksaksj', 'En Progres');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `assignetache`
--
ALTER TABLE `assignetache`
  ADD PRIMARY KEY (`idtache`,`idmembre`),
  ADD KEY `idtache` (`idtache`),
  ADD KEY `idmembre` (`idmembre`);

--
-- Indexes for table `membre`
--
ALTER TABLE `membre`
  ADD PRIMARY KEY (`idmembre`),
  ADD UNIQUE KEY `idmembre` (`idmembre`);

--
-- Indexes for table `tache`
--
ALTER TABLE `tache`
  ADD PRIMARY KEY (`idtache`),
  ADD UNIQUE KEY `idtache` (`idtache`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `assignetache`
--
ALTER TABLE `assignetache`
  ADD CONSTRAINT `assignetache_ibfk_1` FOREIGN KEY (`idmembre`) REFERENCES `membre` (`idmembre`),
  ADD CONSTRAINT `assignetache_ibfk_2` FOREIGN KEY (`idtache`) REFERENCES `tache` (`idtache`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
